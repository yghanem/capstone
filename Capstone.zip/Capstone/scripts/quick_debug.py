import os
import pandas as pd
CSV_PATH = os.path.join(os.path.dirname(__file__), "Project1-Comprehensive_Banking_Database-new.csv")
df = pd.read_csv(CSV_PATH)
no_loans = (df["CustomerLoanCount"] == 0)
mask = no_loans & (df["RowType"] != "Loan") & (
    (df["Loan ID"] != 0) | (df["Loan Amount"] != 0) | (df["Loan Type"].astype(str) != "")
)
print("violations:", mask.sum())
print(df.loc[mask, ["Customer ID","RowType","CustomerLoanCount","Loan ID","Loan Amount","Loan Type"]].head(10).to_string(index=False))
