import os
import sys
import pandas as pd
import numpy as np
import random
from datetime import datetime, timedelta

# Avoid shadowing the 'faker' package if a local faker.py exists
_cwd = os.path.dirname(os.path.abspath(__file__))
_local_shadow = os.path.join(_cwd, "faker.py")
if os.path.exists(_local_shadow):
    try:
        sys.path.remove(_cwd)
    except ValueError:
        pass
from faker import Faker

fake = Faker("en_US")
np.random.seed(42)
random.seed(42)

# Number of records
N = 10000

# Helper functions
def random_date(start, end):
    return (start + timedelta(days=random.randint(0, (end-start).days))).strftime("%m/%d/%Y")

def random_card_type():
    return random.choice(["Visa", "MasterCard", "Amex"])

def random_loan_type():
    return random.choice(["Home Loan", "Car Loan", "Personal Loan", "Education Loan"])

def segment_from_risk(income, credit_score, balance):
    if credit_score < 580:
        return "High Risk"
    elif income > 100000 and balance > 50000:
        return "High Value"
    elif income < 40000:
        return "Budget"
    else:
        return random.choice(["At Risk", "Digital Enthusiast", "Stable"])

def feedback_text(fb_type):
    if fb_type == "Complaint":
        return random.choice([
            "Service was too slow at the branch.",
            "Unexpected fees applied to my account.",
            "Mobile app keeps crashing, very frustrating.",
            "Loan approval process took too long.",
            "Customer support was unhelpful."
        ])
    elif fb_type == "Praise":
        return random.choice([
            "Excellent customer service, very helpful staff.",
            "Mobile banking app is smooth and easy to use.",
            "Fast loan approval, very satisfied.",
            "Great rewards program, I love it!",
            "I really appreciate the transparency of fees."
        ])
    elif fb_type == "Suggestion":
        return random.choice([
            "Please add more ATMs in my area.",
            "It would be great to have 24/7 customer support.",
            "Consider lowering fees for small accounts.",
            "Add biometric login to the mobile app.",
            "Offer more flexible loan repayment plans."
        ])
    return ""

# Original 40 columns
original_columns = [
    "Customer ID","First Name","Last Name","Age","Gender","Address","City","Contact Number","Email",
    "Account Type","Account Balance","Date Of Account Opening","Last Transaction Date",
    "TransactionID","Transaction Date","Transaction Type","Transaction Amount",
    "Account Balance After Transaction","Branch ID","Loan ID","Loan Amount","Loan Type",
    "Interest Rate","Loan Term","Approval/Rejection Date","Loan Status","CardID","Card Type",
    "Credit Limit","Credit Card Balance","Minimum Payment Due","Payment Due Date",
    "Last Credit Card Payment Date","Rewards Points","Feedback ID","Feedback Date",
    "Feedback Type","Resolution Status","Resolution Date","Anomaly"
]

# Add 4 new columns
columns = original_columns + ["ChurnLikelihood","CustomerSegment","DigitalEngagementScore","FeedbackText"]

# Generate synthetic dataset
data = []
for i in range(1, N+1):
    first = fake.first_name()
    last = fake.last_name()
    age = random.randint(18, 80)
    gender = random.choice(["Male", "Female", "Other"])
    address = fake.street_address()
    city = fake.city()
    contact = fake.msisdn()[:11]
    email = f"{first.lower()}.{last.lower()}@example.com"

    acc_type = random.choice(["Current", "Savings"])
    acc_balance = round(random.uniform(100, 100000), 2)
    date_opening = random_date(datetime(2000,1,1), datetime(2023,12,31))
    last_transaction_date = random_date(datetime(2022,1,1), datetime(2023,12,31))

    # Transactions
    trans_id = i
    trans_date = random_date(datetime(2020,1,1), datetime(2023,12,31))
    trans_type = random.choice(["Deposit", "Withdrawal", "Payment", "Transfer"])
    trans_amt = round(random.uniform(10, 5000), 2)
    acc_after = round(acc_balance + random.uniform(-1000, 1000), 2)
    branch_id = random.randint(1, 50)

    # Loans: 40% chance to have applied
    loan_id = i
    if random.random() < 0.4:
        loan_status = random.choice(["Approved", "Closed", "Rejected"])
        if loan_status == "Rejected":
            loan_amt, loan_type, interest, loan_term, approval_date = 0, None, 0, 0, None
        else:
            loan_amt = round(random.uniform(1000, 200000), 2)
            loan_type = random_loan_type()
            interest = round(random.uniform(2, 15), 2)
            loan_term = random.choice([12,24,36,60,120])
            approval_date = random_date(datetime(2015,1,1), datetime(2023,12,31))
    else:
        loan_amt, loan_type, interest, loan_term, approval_date, loan_status = 0, None, 0, 0, None, None

    # Cards: 60% chance to have one
    card_id = i
    if random.random() < 0.6:
        card_type = random_card_type()
        credit_limit = round(random.uniform(1000,20000),2)
        cc_balance = round(random.uniform(0,credit_limit),2)
        min_due = round(cc_balance * random.uniform(0.01,0.05),2)
        due_date = random_date(datetime(2023,1,1), datetime(2023,12,31))
        last_payment = random_date(datetime(2022,1,1), datetime(2023,12,31))
    else:
        card_type, credit_limit, cc_balance, min_due, due_date, last_payment = None, 0, 0, 0, None, None

    # Feedback
    fb_id = i
    fb_date = random_date(datetime(2022,1,1), datetime(2023,12,31))
    fb_type = random.choice(["Complaint","Praise","Suggestion"])
    resolution_status = random.choice(["Resolved","Pending"])
    resolution_date = random_date(datetime(2022,1,1), datetime(2023,12,31)) if resolution_status=="Resolved" else None
    anomaly = random.choice([0,1])
    rewards_points = random.randint(0,10000)

    feedback_text_value = feedback_text(fb_type)

    # Derived fields
    credit_score = random.randint(300, 850)
    income = random.randint(20000, 200000)

    churn_prob = round(random.uniform(0,1),2)
    customer_segment = segment_from_risk(income, credit_score, acc_balance)
    digital_score = random.randint(0,100)

    data.append([
        i, first, last, age, gender, address, city, contact, email,
        acc_type, acc_balance, date_opening, last_transaction_date,
        trans_id, trans_date, trans_type, trans_amt, acc_after, branch_id,
        loan_id, loan_amt, loan_type, interest, loan_term, approval_date, loan_status,
        card_id, card_type, credit_limit, cc_balance, min_due, due_date, last_payment,
        rewards_points, fb_id, fb_date, fb_type, resolution_status, resolution_date, anomaly,
        churn_prob, customer_segment, digital_score, feedback_text_value
    ])

# Build DataFrame
synthetic_df = pd.DataFrame(data, columns=columns)

# Save to CSV (aligned with existing file name)
synthetic_df.to_csv("Synthetic_Banking_Customers2.csv", index=False)

# Preview
print(synthetic_df.head(10))
