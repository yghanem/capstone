import os
import pandas as pd


def main():
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    star = os.path.join(root, 'star_schema')
    out_dir = os.path.join(root, 'output')
    os.makedirs(out_dir, exist_ok=True)

    trx = pd.read_csv(os.path.join(star, 'Transactions.csv'))
    loans = pd.read_csv(os.path.join(star, 'Loans.csv'))
    feedback = pd.read_csv(os.path.join(star, 'Feedback.csv'))
    customers = pd.read_csv(os.path.join(star, 'Customers.csv'))

    # Branch transaction distribution
    bt_counts = trx['Branch ID'].value_counts().rename('Transactions').to_frame()
    # Attach branch meta from Customers to get names/cities (take first occurrence per branch)
    branch_meta = customers.groupby(['Branch ID','Branch Name','City','State']).size().reset_index().drop(columns=0)
    bt = branch_meta.merge(bt_counts, left_on='Branch ID', right_index=True, how='left').fillna({'Transactions':0}).astype({'Transactions':int})
    bt['Txn Share %'] = (bt['Transactions'] / bt['Transactions'].sum() * 100).round(2)
    bt.sort_values('Transactions', ascending=False, inplace=True)
    bt.to_csv(os.path.join(out_dir, 'Branch_Txn_Distribution.csv'), index=False)

    # Loan types distribution overall and by city
    loans_overall = loans['Loan Type'].value_counts(normalize=True).mul(100).round(2).rename('Percent').to_frame()
    loans_overall.to_csv(os.path.join(out_dir, 'Loan_Type_Distribution.csv'))
    loans_city = loans.merge(customers[['Customer ID','City']], on='Customer ID', how='left')
    lt_city = loans_city.groupby('City')['Loan Type'].value_counts(normalize=True).mul(100).round(2).rename('Percent').reset_index()
    lt_city_pivot = lt_city.pivot(index='City', columns='Loan Type', values='Percent').fillna(0).reset_index()
    lt_city_pivot.to_csv(os.path.join(out_dir, 'Loan_Type_By_City.csv'), index=False)

    # Feedback type distribution and pending rate by type
    fb_type = feedback['Feedback Type'].value_counts(normalize=True).mul(100).round(2).rename('Percent').to_frame()
    fb_type.to_csv(os.path.join(out_dir, 'Feedback_Type_Distribution.csv'))
    fb_pending = feedback.groupby('Feedback Type')['Resolution Status'].apply(lambda s: (s=='Pending').mean()*100).round(2).rename('Pending %').to_frame()
    fb_pending.to_csv(os.path.join(out_dir, 'Feedback_Pending_By_Type.csv'))

    # Print concise summaries
    print('Branch Txn Distribution (top 10):')
    print(bt.head(10).to_string(index=False))
    print('\nLoan Type Distribution (%):')
    print(loans_overall.to_string())
    print('\nFeedback Type Distribution (%):')
    print(fb_type.to_string())
    print('\nFeedback Pending Rate by Type (%):')
    print(fb_pending.to_string())


if __name__ == '__main__':
    main()
