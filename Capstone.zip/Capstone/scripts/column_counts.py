import csv
import os
from glob import glob


def count_columns(path: str) -> int:
    with open(path, 'r', newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        header = next(reader)
        return len(header), header


def main() -> None:
    base = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    targets = []

    # Flat files
    src = os.path.join(base, 'source', 'Project1-Comprehensive_Banking_Database.csv')
    out = os.path.join(base, 'output', 'Project1-Comprehensive_Banking_Database-new.csv')
    if os.path.exists(src):
        targets.append(('flat_original', src))
    if os.path.exists(out):
        targets.append(('flat_new', out))

    # Star schema files
    star_dir = os.path.join(base, 'star_schema')
    star_files = [
        ('star_Customers', os.path.join(star_dir, 'Customers.csv')),
        ('star_Accounts', os.path.join(star_dir, 'Accounts.csv')),
        ('star_Cards', os.path.join(star_dir, 'Cards.csv')),
        ('star_Loans', os.path.join(star_dir, 'Loans.csv')),
        ('star_Transactions', os.path.join(star_dir, 'Transactions.csv')),
        ('star_Feedback', os.path.join(star_dir, 'Feedback.csv')),
        ('star_Branches', os.path.join(star_dir, 'Branches.csv')),
    ]
    for name, path in star_files:
        if os.path.exists(path):
            targets.append((name, path))

    if not targets:
        print('No target CSV files found.')
        return

    print('Column counts:')
    for name, path in targets:
        try:
            n, header = count_columns(path)
            print(f"- {name}: {n} columns  | file: {os.path.relpath(path, base)}")
        except Exception as e:
            print(f"- {name}: ERROR reading {path}: {e}")


if __name__ == '__main__':
    main()
import os
import pandas as pd
BASE = os.path.dirname(__file__)
files = {
    'Flat': os.path.join(BASE, 'Project1-Comprehensive_Banking_Database-new.csv'),
    'Customers': os.path.join(BASE, 'star_schema', 'Customers.csv'),
    'Accounts': os.path.join(BASE, 'star_schema', 'Accounts.csv'),
    'Cards': os.path.join(BASE, 'star_schema', 'Cards.csv'),
    'Loans': os.path.join(BASE, 'star_schema', 'Loans.csv'),
    'Transactions': os.path.join(BASE, 'star_schema', 'Transactions.csv'),
    'Feedback': os.path.join(BASE, 'star_schema', 'Feedback.csv'),
}
for name, path in files.items():
    try:
        df = pd.read_csv(path, nrows=1)
        print(f"{name}: {len(df.columns)} columns")
    except Exception as e:
        print(f"{name}: ERROR reading {path}: {e}")
