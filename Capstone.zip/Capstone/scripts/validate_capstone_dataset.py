import os
import re
from datetime import datetime
from typing import List, Dict

import pandas as pd

DATE_FMT = "%m/%d/%Y"
ALLOWED_ROW_TYPES = {"Transaction","Card","Loan","Account","Snapshot"}
ALLOWED_TXN_TYPES = {"Deposit","Withdrawal","Payment","Transfer"}

_CWD = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.abspath(os.path.join(_CWD, os.pardir))
CSV_PATH = os.path.join(_ROOT, "output", "Project1-Comprehensive_Banking_Database-new.csv")


def parse_date_ok(s: str) -> bool:
    if not s or str(s).strip() == "":
        return True
    try:
        datetime.strptime(str(s), DATE_FMT)
        return True
    except Exception:
        return False


def load_df() -> pd.DataFrame:
    # keep_default_na=False prevents empty strings from becoming NaN
    print("Loading CSV...")
    df = pd.read_csv(CSV_PATH, keep_default_na=False)
    print(f"Loaded {len(df):,} rows. Building defaults...")
    # Ensure columns exist even if missing
    for col in [
        "RowType","EntitySequence","AccountID","CustomerHasCards","CustomerHasLoans","CustomerHasMultipleAccounts",
        "CustomerCardCount","CustomerLoanCount","CustomerAccountCount","CustomerTxnCount",
        "State","Zip Code","Country",
        "ChurnLikelihood","CustomerSegment","DigitalEngagementScore","FeedbackText"
    ]:
        if col not in df.columns:
            df[col] = ""
    return df


def add_issue(issues: List[Dict], rule: str, row: pd.Series, details: str):
    issues.append({
        "rule": rule,
        "Customer ID": row.get("Customer ID", None),
        "RowType": row.get("RowType", None),
        "EntitySequence": row.get("EntitySequence", None),
        "TransactionID": row.get("TransactionID", None),
        "Loan ID": row.get("Loan ID", None),
        "CardID": row.get("CardID", None),
        "details": details,
})


def validate(df: pd.DataFrame) -> pd.DataFrame:
    issues: List[Dict] = []

    print("Checking basic schema (row types and txn types)...")
    # Vectorized basic checks
    invalid_rowtype = ~df["RowType"].isin(ALLOWED_ROW_TYPES)
    for idx, r in df.loc[invalid_rowtype].head(200).iterrows():
        add_issue(issues, "rowtype.invalid", r, f"RowType={r['RowType']}")
    txn_mask = df["RowType"] == "Transaction"
    invalid_txn_type = txn_mask & ~df["Transaction Type"].isin(ALLOWED_TXN_TYPES)
    for idx, r in df.loc[invalid_txn_type].head(200).iterrows():
        add_issue(issues, "txn.type.invalid", r, f"Transaction Type={r['Transaction Type']}")

    print("Checking US address fields...")
    # US address checks
    state_ok = df["State"].astype(str).str.fullmatch(r"[A-Z]{2}")
    zipcode_ok = df["Zip Code"].astype(str).str.fullmatch(r"\d{5}(?:-\d{4})?")
    country_ok = df["Country"].astype(str).eq("United States")
    for idx, r in df.loc[~state_ok].head(200).iterrows():
        add_issue(issues, "address.state", r, f"State={r['State']}")
    for idx, r in df.loc[~zipcode_ok].head(200).iterrows():
        add_issue(issues, "address.zip", r, f"Zip Code={r['Zip Code']}")
    for idx, r in df.loc[~country_ok].head(200).iterrows():
        add_issue(issues, "address.country", r, f"Country={r['Country']}")

    print("Checking date parsing...")
    # Date parse checks (only for non-empty)
    date_cols = [
        "Date Of Account Opening","Last Transaction Date","Transaction Date",
        "Approval/Rejection Date","Payment Due Date","Last Credit Card Payment Date",
        "Feedback Date","Resolution Date","EventTimestamp"
    ]
    for c in date_cols:
        if c in df.columns:
            bad = ~df[c].astype(str).apply(parse_date_ok)
            for idx, r in df.loc[bad].head(200).iterrows():
                add_issue(issues, "date.parse", r, f"col={c} val={r[c]}")

    print("Checking loan consistency...")
    # Loans consistency
    # Rejected loans: amounts/rates/term zero; decision date present
    rej = (df["Loan Status"].astype(str) == "Rejected")
    bad_rej = df.loc[rej & (
        (df["Loan Amount"] != 0) | (df["Interest Rate"] != 0) | (df["Loan Term"] != 0) | (df["Approval/Rejection Date"].astype(str) == "")
    )]
    for idx, r in bad_rej.iterrows():
        add_issue(issues, "loan.rejected", r, "Rejected loan has non-zero values or missing decision date")

    # Approved/Closed loans must have positive values and dates
    ac = df["Loan Status"].astype(str).isin(["Approved","Closed"])
    bad_ac = df.loc[ac & (
        (df["Loan Amount"] <= 0) | (df["Interest Rate"] <= 0) | (df["Loan Term"] <= 0) | (df["Approval/Rejection Date"].astype(str) == "")
    )]
    for idx, r in bad_ac.iterrows():
        add_issue(issues, "loan.approved_closed", r, "Approved/Closed loan missing required positive values/date")

    # Customers with no loans should have loan fields empty/zero on non-loan rows
    no_loans = (df["CustomerLoanCount"] == 0)
    # Check rows where RowType != Loan
    mask = no_loans & (df["RowType"] != "Loan") & (
        (df["Loan ID"] != 0) | (df["Loan Amount"] != 0) | (df["Loan Type"].astype(str) != "")
    )
    for idx, r in df.loc[mask].iterrows():
        add_issue(issues, "loan.no_loans_customer", r, "CustomerLoanCount=0 but loan fields populated on non-loan row")

    print("Checking transaction account linkage...")
    # Transactions must have an account
    bad_txn = df.loc[(df["RowType"] == "Transaction") & (df["AccountID"] == 0)]
    for idx, r in bad_txn.iterrows():
        add_issue(issues, "txn.no_account", r, "Transaction row with AccountID=0")

    # Cards consistency
    # Card rows must have card details
    bad_card = df.loc[(df["RowType"] == "Card") & (
        (df["CardID"] == 0) | (df["Card Type"].astype(str) == "") | (df["Credit Limit"] <= 0)
    )]
    for idx, r in bad_card.iterrows():
        add_issue(issues, "card.row_missing", r, "Card row missing card details")

    print("Checking card consistency...")
    # Customers with no cards should not have card fields on non-card rows
    no_cards = (df["CustomerCardCount"] == 0)
    mask = no_cards & (df["RowType"] != "Card") & (
        (df["CardID"] != 0) | (df["Card Type"].astype(str) != "") | (df["Credit Limit"] != 0) | (df["Credit Card Balance"] != 0)
    )
    for idx, r in df.loc[mask].iterrows():
        add_issue(issues, "card.no_cards_customer", r, "CustomerCardCount=0 but card fields populated on non-card row")

    # Card date ordering and amounts
    def cmp_dates(a, b) -> bool:
        try:
            da = datetime.strptime(str(a), DATE_FMT)
            db = datetime.strptime(str(b), DATE_FMT)
            return da <= db
        except Exception:
            return True
    card_mask = df["CardID"] > 0
    for idx, r in df.loc[card_mask].iterrows():
        if r["Minimum Payment Due"] > r["Credit Card Balance"] + 1e-6:
            add_issue(issues, "card.min_due", r, "Minimum Payment Due exceeds Credit Card Balance")
        if r["Credit Card Balance"] > r["Credit Limit"] + 1e-6:
            add_issue(issues, "card.balance_limit", r, "Credit Card Balance exceeds Credit Limit")
        if r["Payment Due Date"] and r["Last Credit Card Payment Date"]:
            if not cmp_dates(r["Last Credit Card Payment Date"], r["Payment Due Date"]):
                add_issue(issues, "card.date_order", r, "Last payment after due date")

    print("Checking transaction amounts and dates...")
    # Transactions: amount positive (vectorized)
    bad_amt = (df["RowType"] == "Transaction") & (df["Transaction Amount"] <= 0)
    for idx, r in df.loc[bad_amt].head(200).iterrows():
        add_issue(issues, "txn.amount_positive", r, "Transaction Amount <= 0")

    print("Checking Last Transaction Date per customer...")
    # Last Transaction Date per customer equals max Transaction Date among txn rows (if any)
    # Build a map of max dates per customer
    txn_df = df.loc[df["RowType"] == "Transaction", ["Customer ID","Transaction Date"]].copy()
    if not txn_df.empty:
        txn_df["Transaction Date Parsed"] = pd.to_datetime(txn_df["Transaction Date"], format=DATE_FMT, errors="coerce")
        latest_map = txn_df.groupby("Customer ID")["Transaction Date Parsed"].max()
        ltd = df[["Customer ID","Last Transaction Date"]].drop_duplicates()
        ltd["Last Transaction Date Parsed"] = pd.to_datetime(ltd["Last Transaction Date"], format=DATE_FMT, errors="coerce")
        merged = ltd.merge(latest_map, left_on="Customer ID", right_index=True, how="left")
        bad = merged.loc[(~merged["Transaction Date Parsed"].isna()) & (merged["Last Transaction Date Parsed"] != merged["Transaction Date Parsed"]) ]
        bad_ids = set(bad["Customer ID"].tolist())
        for idx, r in df.loc[df["Customer ID"].isin(bad_ids)].head(200).iterrows():
            add_issue(issues, "customer.last_txn_date", r, "Last Transaction Date does not match max txn date")

    print("Checking business rules...")
    # Additional business rules
    # 1) Only customers with credit cards have rewards (Rewards Points > 0)
    cust_cards = df.groupby("Customer ID")["CustomerCardCount"].max()
    cust_rewards = df.groupby("Customer ID")["Rewards Points"].max()
    viol_ids = [cid for cid, rp in cust_rewards.items() if rp > 0 and cust_cards.get(cid, 0) == 0]
    for idx, r in df.loc[df["Customer ID"].isin(viol_ids)].head(200).iterrows():
        add_issue(issues, "rewards.no_card", r, "Rewards Points > 0 but customer has no cards")

    # 2) Any customer with a loan or a credit card must have a checking (Current) account
    # Build per-customer account types
    acct_types = df.loc[df["RowType"] == "Account", ["Customer ID","Account Type"]]
    has_current = acct_types.groupby("Customer ID")["Account Type"].apply(lambda s: (s == "Current").any())
    cust_loans = df.groupby("Customer ID")["CustomerLoanCount"].max()
    need_current = [cid for cid in cust_cards.index.union(cust_loans.index)
                    if (cust_cards.get(cid, 0) > 0 or cust_loans.get(cid, 0) > 0) and not bool(has_current.get(cid, False))]
    for idx, r in df.loc[df["Customer ID"].isin(need_current)].head(200).iterrows():
        add_issue(issues, "account.current_required", r, "Customer has loans/cards but no Current account")

    # 3) Transaction counts between 25 and 100 when accounts exist
    txn_counts = df.loc[df["RowType"] == "Transaction"].groupby("Customer ID").size()
    acct_counts = df.loc[df["RowType"] == "Account"].groupby("Customer ID").size()
    for cid, cnt in txn_counts.items():
        if acct_counts.get(cid, 0) > 0 and not (25 <= cnt <= 100):
            for idx, r in df.loc[df["Customer ID"] == cid].head(1).iterrows():
                add_issue(issues, "txn.count_range", r, f"Transactions={cnt} outside [25,100]")

    # 4) Transaction dates in 2024–2025
    mask = (df["RowType"] == "Transaction") & ~df["Transaction Date"].astype(str).apply(lambda s: in_range_date(s, "01/01/2024", "12/31/2025"))
    for idx, r in df.loc[mask].head(200).iterrows():
        add_issue(issues, "txn.date_range", r, "Transaction Date outside 2024-2025")

    # 5) Account open dates 2010–2025
    mask = (df["RowType"] == "Account") & ~df["Date Of Account Opening"].astype(str).apply(lambda s: in_range_date(s, "01/01/2010", "12/31/2025"))
    for idx, r in df.loc[mask].head(200).iterrows():
        add_issue(issues, "account.open_date_range", r, "Account opening date outside 2010-2025")

    # 6) Rejected loan decision dates 2024–2025
    mask = (df["RowType"] == "Loan") & (df["Loan Status"] == "Rejected") & ~df["Approval/Rejection Date"].astype(str).apply(lambda s: in_range_date(s, "01/01/2024", "12/31/2025"))
    for idx, r in df.loc[mask].head(200).iterrows():
        add_issue(issues, "loan.rejected_date_range", r, "Rejected loan date outside 2024-2025")

    print("Assembling issues DataFrame...")
    return pd.DataFrame(issues)


def in_range_date(s: str, start: str, end: str) -> bool:
    if not s or str(s).strip() == "":
        return True
    try:
        d = datetime.strptime(str(s), DATE_FMT)
        return datetime.strptime(start, DATE_FMT) <= d <= datetime.strptime(end, DATE_FMT)
    except Exception:
        return True


def main():
    df = load_df()
    print("Validating...")
    issues = validate(df)

    total = len(df)
    customers = df["Customer ID"].nunique()
    by_rowtype = df.groupby("RowType").size().reset_index(name="rows")

    print("Validation Summary")
    print("===================")
    print(f"Rows: {total:,} | Customers: {customers:,}")
    print(by_rowtype.to_string(index=False))
    print()

    # Ensure validation output directory exists at root/validation
    val_dir = os.path.join(_ROOT, "validation")
    os.makedirs(val_dir, exist_ok=True)

    if issues.empty:
        print("No issues found.")
        # Still emit empty CSVs for consistency
        issues.to_csv(os.path.join(val_dir, "validation_issues.csv"), index=False)
        pd.DataFrame(columns=["rule","violations"]).to_csv(os.path.join(val_dir, "validation_summary.csv"), index=False)
        return

    summary = issues.groupby("rule").size().reset_index(name="violations").sort_values("violations", ascending=False)
    print(summary.to_string(index=False))

    # Write detailed outputs
    issues.to_csv(os.path.join(val_dir, "validation_issues.csv"), index=False)
    summary.to_csv(os.path.join(val_dir, "validation_summary.csv"), index=False)


if __name__ == "__main__":
    main()
