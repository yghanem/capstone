import os
import sys
import random
import argparse
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

import numpy as np
import pandas as pd

# Avoid shadowing the 'faker' package if a local faker.py exists
_CWD = os.path.dirname(os.path.abspath(__file__))
# Project root is parent of the scripts directory
_ROOT = os.path.abspath(os.path.join(_CWD, os.pardir))
_local_shadow = os.path.join(_CWD, "faker.py")
if os.path.exists(_local_shadow):
    try:
        sys.path.remove(_CWD)
    except ValueError:
        pass

from faker import Faker

rng = random.Random(42)
np.random.seed(42)
fake = Faker("en_US")

# Config
NUM_CUSTOMERS = 1200  # default; can be overridden via --customers
MIN_TXNS_PER_CUST = 25
MAX_TXNS_PER_CUST = 100
DATE_FMT = "%m/%d/%Y"

# Regions (state abbreviations)
REGION_STATES = {
    "east": [
        "CT","DE","FL","GA","ME","MD","MA","NH","NJ","NY","NC","PA","RI","SC","VA","VT","WV",
        "AL","MS","TN","KY","OH","MI","IN","IL","WI","DC"
    ],
    "west": [
        "AK","AZ","CA","CO","HI","ID","MT","NM","NV","OR","UT","WA","WY"
    ]
}

# Representative cities per region for realism
REGION_CITIES = {
    "east": [
        "New York","Boston","Philadelphia","Washington","Miami","Atlanta","Charlotte","Pittsburgh",
        "Baltimore","Orlando","Tampa","Raleigh","Nashville","Cleveland","Columbus","Detroit",
        "Indianapolis","Milwaukee","Buffalo","Richmond","Hartford","Providence","Newark"
    ],
    "west": [
        "Los Angeles","San Francisco","San Diego","Seattle","Portland","Phoenix","Denver","Las Vegas",
        "Salt Lake City","Albuquerque","Honolulu","Boise","Spokane","Tucson","Oakland","Sacramento"
    ]
}

# Customer profile presets to bias demographics and product mix
PROFILE_CONFIG = {
    "balanced": {
        "age_range": (22, 75),
        "income_range": (30000, 120000),
        "credit_score_range": (580, 780),
        "accounts_probs": (0.2, 0.6),  # p0, p1; rest -> multi
        "cards_scale": 1.0,            # >1.0 means more cards
        "loans_scale": 1.0,            # >1.0 means more loans
        "txns_mean": 8,
        "churn_range": (0.05, 0.6),
        "digital_range": (20, 85),
        "loan_reject_bias": 1.0        # >1.0 more rejections; <1.0 fewer
    },
    "high_value": {
        "age_range": (28, 70),
        "income_range": (100000, 220000),
        "credit_score_range": (680, 850),
        "accounts_probs": (0.05, 0.55),
        "cards_scale": 1.3,
        "loans_scale": 1.3,
        "txns_mean": 10,
        "churn_range": (0.0, 0.3),
        "digital_range": (40, 95),
        "loan_reject_bias": 0.7
    },
    "budget": {
        "age_range": (18, 55),
        "income_range": (20000, 45000),
        "credit_score_range": (520, 700),
        "accounts_probs": (0.3, 0.6),
        "cards_scale": 0.8,
        "loans_scale": 0.8,
        "txns_mean": 6,
        "churn_range": (0.2, 0.8),
        "digital_range": (15, 70),
        "loan_reject_bias": 1.2
    },
    "at_risk": {
        "age_range": (21, 65),
        "income_range": (25000, 70000),
        "credit_score_range": (500, 680),
        "accounts_probs": (0.25, 0.6),
        "cards_scale": 0.9,
        "loans_scale": 1.0,
        "txns_mean": 7,
        "churn_range": (0.5, 0.95),
        "digital_range": (10, 75),
        "loan_reject_bias": 1.3
    },
    "digital_enthusiast": {
        "age_range": (18, 60),
        "income_range": (40000, 130000),
        "credit_score_range": (600, 800),
        "accounts_probs": (0.15, 0.6),
        "cards_scale": 1.2,
        "loans_scale": 1.0,
        "txns_mean": 12,
        "churn_range": (0.05, 0.5),
        "digital_range": (70, 100),
        "loan_reject_bias": 0.9
    }
}

def get_profile_cfg(name: str) -> Dict[str, Any]:
    base = PROFILE_CONFIG["balanced"].copy()
    if name in PROFILE_CONFIG and name != "balanced":
        base.update(PROFILE_CONFIG[name])
    return base

# Original 40 columns (keep names/types)
ORIGINAL_COLS: List[str] = [
    "Customer ID","First Name","Last Name","Age","Gender","Address","City","Contact Number","Email",
    "Account Type","Account Balance","Date Of Account Opening","Last Transaction Date",
    "TransactionID","Transaction Date","Transaction Type","Transaction Amount",
    "Account Balance After Transaction","Branch ID","Loan ID","Loan Amount","Loan Type",
    "Interest Rate","Loan Term","Approval/Rejection Date","Loan Status","CardID","Card Type",
    "Credit Limit","Credit Card Balance","Minimum Payment Due","Payment Due Date",
    "Last Credit Card Payment Date","Rewards Points","Feedback ID","Feedback Date",
    "Feedback Type","Resolution Status","Resolution Date","Anomaly"
]

# Appended helper columns
EXTRA_COLS: List[str] = [
    "RowType",  # Transaction | Card | Loan | Account | Snapshot
    "EntitySequence",  # 1..n per entity per customer
    "AccountID",  # stable account id for account/txn rows
    "CustomerHasCards","CustomerHasLoans","CustomerHasMultipleAccounts",
    "CustomerCardCount","CustomerLoanCount","CustomerAccountCount","CustomerTxnCount",
    "EventTimestamp",
    # Branch enrichment
    "Branch Name",
    # US address enrichment
    "State","Zip Code","Country",
    # Requested enrichment fields
    "ChurnLikelihood","CustomerSegment","DigitalEngagementScore","FeedbackText"
]

ALL_COLS = ORIGINAL_COLS + EXTRA_COLS

# Helper funcs

def rand_date(start: datetime, end: datetime) -> str:
    """Return a random date string between start and end using DATE_FMT (mm/dd/yyyy)."""
    days = (end - start).days
    return (start + timedelta(days=rng.randint(0, max(0, days)))).strftime(DATE_FMT)


def pick(seq):
    """Random choice using the module RNG (seeded for reproducibility)."""
    return rng.choice(seq)

def wchoice(items: List[Any], weights: List[float]) -> Any:
    total = sum(weights)
    r = rng.random() * total
    acc = 0.0
    for item, w in zip(items, weights):
        acc += w
        if r <= acc:
            return item
    return items[-1]


def gen_phone() -> str:
    """Generate an 11-digit phone number akin to the sample dataset."""
    # 11 digits similar to sample
    return fake.msisdn()[:11]


def make_feedback(has_card: bool) -> Dict[str, Any]:
    """Create a per-customer feedback record including text and points."""
    # Weighted feedback type distribution (not equal), with slight cardholder bias
    base_w = {"Complaint": 0.34, "Praise": 0.26, "Suggestion": 0.40}
    if has_card:
        adj = {"Complaint": 1.10, "Praise": 1.08, "Suggestion": 0.92}
    else:
        adj = {"Complaint": 1.0, "Praise": 1.0, "Suggestion": 1.0}
    weights = {k: base_w[k]*adj.get(k,1.0) for k in base_w}
    s = sum(weights.values())
    probs = [weights[k]/s for k in ["Complaint","Praise","Suggestion"]]
    fb_type = wchoice(["Complaint","Praise","Suggestion"], probs)
    text_map = {
        "Complaint": [
            "Service was too slow at the branch.",
            "Unexpected fees applied to my account.",
            "Mobile app keeps crashing, very frustrating.",
            "Loan approval process took too long.",
            "Customer support was unhelpful."
        ],
        "Praise": [
            "Excellent customer service, very helpful staff.",
            "Mobile banking app is smooth and easy to use.",
            "Fast loan approval, very satisfied.",
            "Great rewards program, I love it!",
            "I really appreciate the transparency of fees."
        ],
        "Suggestion": [
            "Please add more ATMs in my area.",
            "It would be great to have 24/7 customer support.",
            "Consider lowering fees for small accounts.",
            "Add biometric login to the mobile app.",
            "Offer more flexible loan repayment plans."
        ]
    }
    # More complaints remain pending than praise/suggestions
    pending_prob = 0.55 if fb_type == "Complaint" else 0.35
    res_status = wchoice(["Resolved","Pending"], [1-pending_prob, pending_prob])
    return {
        "Feedback ID": 0,
        "Feedback Date": rand_date(datetime(2022,1,1), datetime(2024,12,31)),
        "Feedback Type": fb_type,
        "Resolution Status": res_status,
        "Resolution Date": rand_date(datetime(2022,1,1), datetime(2024,12,31)) if res_status=="Resolved" else "",
        # Only customers with credit cards have rewards
        "Rewards Points": (rng.randint(100, 10000) if has_card else 0),
        "FeedbackText": pick(text_map[fb_type])
    }


def zero_row() -> Dict[str, Any]:
    """Base row with ORIGINAL_COLS initialized (numeric=0, strings="")."""
    # default values per type (numbers 0; strings "")
    row = {k: 0 for k in ORIGINAL_COLS}
    # Set string-like defaults to ""
    for k in ["First Name","Last Name","Gender","Address","City","Email","Account Type","Date Of Account Opening",
              "Last Transaction Date","Transaction Date","Transaction Type","Loan Type","Approval/Rejection Date",
              "Loan Status","Card Type","Payment Due Date","Last Credit Card Payment Date","Feedback Date",
              "Feedback Type","Resolution Status","Resolution Date"]:
        row[k] = ""
    return row


def make_customer(cust_id: int, region: str = "all", profile_cfg: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Create a base customer with US address fields (State, Zip Code, Country).

    region: 'all' | 'east' | 'west' — if east/west, restrict state to that region.
    """
    # Gender distribution (not equal)
    gender = wchoice(["Male","Female","Other"], [0.5, 0.48, 0.02])
    first = fake.first_name()
    last = fake.last_name()
    # Assign to a bank branch (weighted across Midwest/East cities) and use its city/state
    branch = choose_branch()
    city = branch["city"]
    address = fake.street_address()
    state = branch["state"]
    zipcode = str(rng.randint(10000, 99999))  # force 5-digit ZIP
    email = f"{first.lower()}.{last.lower()}@example.com"
    # Profile-biased age
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    amin, amax = profile_cfg.get("age_range", (22,75))
    # More realistic age via triangular distribution skewed around 40
    mode_age = min(max(amin, 40), max(amin+1, amax-1))
    age_val = int(rng.triangular(amin, amax, mode_age))

    return {
        "Customer ID": cust_id,
        "First Name": first,
        "Last Name": last,
        "Age": max(18, min(85, age_val)),
        "Gender": gender,
        "Address": address,
        "City": city,
        "Contact Number": gen_phone(),
        "Email": email,
    # Anomaly will be computed later based on behavior; set default 0 here
    "Anomaly": 0,
        # extra address fields
        "State": state,
        "Zip Code": zipcode,
        "Country": "United States",
        "Branch ID": branch["id"],
        "Branch Name": branch["name"],
    }


# Global ID counters
NEXT_ACCOUNT_ID = 1
NEXT_CARD_ID = 1
NEXT_LOAN_ID = 1
NEXT_TXN_ID = 1
NEXT_FB_ID = 1


def gen_accounts(cust_id: int, profile_cfg: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Generate 0–3 accounts with type, balance, and opening date."""
    global NEXT_ACCOUNT_ID
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    p0, p1 = profile_cfg.get("accounts_probs", (0.2, 0.6))
    r = rng.random()
    n = 0 if r < p0 else (1 if r < (p0 + p1) else rng.randint(2,3))
    accounts = []
    for _ in range(n):
        acc_type = pick(["Current","Savings"])
        acc = {
            "AccountID": NEXT_ACCOUNT_ID,
            "Account Type": acc_type,
            "Account Balance": round(rng.uniform(100, 150000), 2),
            # Account open dates between 2010 and 2025
            "Date Of Account Opening": rand_date(datetime(2010,1,1), datetime(2025,12,31))
        }
        NEXT_ACCOUNT_ID += 1
        accounts.append(acc)
    return accounts


def gen_cards(cust_id: int, profile_cfg: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Generate 0–4 cards; ensure Payment Due Date is on/after last payment date."""
    global NEXT_CARD_ID
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    scale = profile_cfg.get("cards_scale", 1.0)
    # base probs
    p0, p12, p34 = 0.40, 0.45, 0.15
    # adjust towards more/less cards
    p12 = max(0.0, min(0.9, p12 * scale))
    # renormalize keeping p0 floor/ceiling reasonable
    total = p0 + p12 + p34
    p0 /= total; p12 /= total; p34 /= total
    r = rng.random()
    n = 0 if r < p0 else (rng.randint(1,2) if r < (p0 + p12) else rng.randint(3,4))
    cards = []
    for _ in range(n):
        card_type = pick(["AMEX","MasterCard","Visa"])  # match Project1 vocab
        credit_limit = round(rng.uniform(1000, 30000), 2)
        # Utilization ~ 0.2..0.55 with avg in that band
        util = 0.2 + rng.betavariate(2.4, 4.0) * (0.55 - 0.2)
        balance = round(credit_limit * util, 2)
        min_due = round(balance * rng.uniform(0.01, 0.05), 2)
        # Ensure due_date is on/after last_payment
        # Card payment and due dates in 2024-2025
        last_payment = rand_date(datetime(2024,1,1), datetime(2025,12,31))
        try:
            lp_dt = datetime.strptime(last_payment, DATE_FMT)
            max_dt = datetime(2025,12,31)
            # Add 0-45 days after last payment, clamp to 2024-12-31
            add_days = rng.randint(0, 45)
            cand = lp_dt + timedelta(days=add_days)
            if cand > max_dt:
                cand = max_dt
            due_date = cand.strftime(DATE_FMT)
        except Exception:
            due_date = rand_date(datetime(2024,1,1), datetime(2025,12,31))
        cards.append({
            "CardID": NEXT_CARD_ID,
            "Card Type": card_type,
            "Credit Limit": credit_limit,
            "Credit Card Balance": balance,
            "Minimum Payment Due": min_due,
            "Payment Due Date": due_date,
            "Last Credit Card Payment Date": last_payment,
        })
        NEXT_CARD_ID += 1
    return cards


# Branch catalog (25 branches across Midwest/East largest cities)
ALLOWED_BRANCH_CITIES = [
    ("New York", "NY"),
    ("Chicago", "IL"),
    ("Philadelphia", "PA"),
    ("Boston", "MA"),
    ("Washington", "DC"),
    ("Charlotte", "NC"),
    ("Columbus", "OH"),
    ("Indianapolis", "IN"),
    ("Jacksonville", "FL"),
    ("Nashville", "TN"),
]

# Approx city weights (millions) from top-25 (east/midwest only), for customer distribution realism
CITY_WEIGHTS = {
    "New York": 8.48,
    "Chicago": 2.72,
    "Philadelphia": 1.57,
    "Boston": 0.67,
    "Washington": 0.70,
    "Charlotte": 0.94,
    "Columbus": 0.93,
    "Indianapolis": 0.89,
    "Jacksonville": 1.01,
    "Nashville": 0.70,
}

def build_branches() -> List[Dict[str, Any]]:
    """Create 25 branches distributed across allowed cities with realistic weights."""
    # city -> number of branches mapping summing to 25
    allocation = {
        ("New York","NY"): 5,
        ("Chicago","IL"): 4,
        ("Philadelphia","PA"): 3,
        ("Boston","MA"): 2,
        ("Washington","DC"): 2,
        ("Charlotte","NC"): 2,
        ("Columbus","OH"): 2,
        ("Indianapolis","IN"): 2,
        ("Jacksonville","FL"): 2,
        ("Nashville","TN"): 1,
    }
    branches = []
    next_id = 1
    for (city, state), count in allocation.items():
        for i in range(1, count+1):
            name = f"{city} Branch {i}" if count > 1 else f"{city} Branch"
            branches.append({
                "id": next_id,
                "name": name,
                "city": city,
                "state": state,
                "weight": 0.0,
            })
            next_id += 1
    return branches


def assign_branch_weights(branches: List[Dict[str, Any]]):
    """Assign per-branch weights so some are high and some low, respecting city populations."""
    # Group indices by city
    from collections import defaultdict
    by_city = defaultdict(list)
    for idx, b in enumerate(branches):
        by_city[b["city"]].append(idx)
    # Split each city's weight among its branches using Dirichlet for variation
    total_weight = 0.0
    for city, idxs in by_city.items():
        city_w = CITY_WEIGHTS.get(city, 1.0)
        # Dirichlet parameters mildly favor inequality
        alpha = [0.8] * len(idxs)
        parts = np.random.dirichlet(alpha)
        for i, part in zip(idxs, parts):
            branches[i]["weight"] = city_w * float(part)
            total_weight += branches[i]["weight"]
    # Normalize to sum 1
    if total_weight > 0:
        for b in branches:
            b["weight"] /= total_weight


BRANCHES = build_branches()
assign_branch_weights(BRANCHES)

def choose_branch() -> Dict[str, Any]:
    ws = [b["weight"] for b in BRANCHES]
    # Fallback uniform if not initialized
    if not any(ws):
        return pick(BRANCHES)
    # Weighted choice
    r = rng.random()
    acc = 0.0
    for b, w in zip(BRANCHES, ws):
        acc += w
        if r <= acc:
            return b
    return BRANCHES[-1]


def gen_loans(cust_id: int, profile_cfg: Optional[Dict[str, Any]] = None, branch_city: Optional[str] = None) -> List[Dict[str, Any]]:
    """Generate 0–3 loans; rejected loans have zero amounts/rate/term and a decision date."""
    global NEXT_LOAN_ID
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    loan_scale = profile_cfg.get("loans_scale", 1.0)
    # base probs: 55% 0, 35% 1, 10% 2-3
    p0, p1, p23 = 0.55, 0.35, 0.10
    # adjust: more loans => reduce p0 slightly, increase p1/p23
    p0 = max(0.2, min(0.9, p0 / loan_scale))
    remaining = 1.0 - p0
    # split remaining in approx original 78:22 ratio
    p1 = remaining * 0.78
    p23 = remaining * 0.22
    r = rng.random()
    n = 0 if r < p0 else (1 if r < (p0 + p1) else rng.randint(2,3))
    loans = []
    # Non-equal loan type distribution (optionally biased by city)
    base_weights = {"Mortgage": 0.45, "Auto": 0.30, "Personal": 0.25}
    city_bias: Dict[str, Dict[str, float]] = {
        # Urban centers: lower auto share, slightly higher personal
        "New York": {"Mortgage": 1.0, "Auto": 0.6, "Personal": 1.2},
        "Chicago": {"Mortgage": 1.0, "Auto": 0.8, "Personal": 1.1},
        "Philadelphia": {"Mortgage": 1.05, "Auto": 0.85, "Personal": 1.0},
        "Boston": {"Mortgage": 1.1, "Auto": 0.75, "Personal": 1.0},
        "Washington": {"Mortgage": 1.05, "Auto": 0.8, "Personal": 1.05},
        # Sunbelt/midwest: higher auto share, mortgages stable
        "Charlotte": {"Mortgage": 1.0, "Auto": 1.2, "Personal": 0.9},
        "Columbus": {"Mortgage": 0.95, "Auto": 1.25, "Personal": 0.9},
        "Indianapolis": {"Mortgage": 0.95, "Auto": 1.3, "Personal": 0.9},
        "Jacksonville": {"Mortgage": 0.95, "Auto": 1.3, "Personal": 0.9},
        "Nashville": {"Mortgage": 1.0, "Auto": 1.2, "Personal": 0.9},
    }

    # Compute final weights
    weights = base_weights.copy()
    if branch_city in city_bias:
        m = city_bias[branch_city]
        for k in weights:
            weights[k] *= m.get(k, 1.0)
        # normalize
        s = sum(weights.values())
        if s > 0:
            for k in list(weights.keys()):
                weights[k] /= s

    loan_types = list(weights.keys())
    loan_type_probs = [weights[k] for k in loan_types]

    for _ in range(n):
        loan_type = wchoice(loan_types, loan_type_probs)  # non-equal distribution
        # bias rejection per profile
        rej_bias = profile_cfg.get("loan_reject_bias", 1.0)
        # base probs A/C/R ~ 0.5/0.35/0.15
        pA, pC, pR = 0.5, 0.35, 0.15
        pR = max(0.02, min(0.6, pR * rej_bias))
        remain = 1.0 - pR
        pA = remain * 0.59
        pC = remain * 0.41
        r = rng.random()
        status = "Rejected" if r < pR else ("Approved" if r < (pR + pA) else "Closed")
        if status == "Rejected":
            # For rejected, amounts/rates/term should be zero, and we keep the rejection date in Approval/Rejection Date
            loan_amt = 0.0
            interest = 0.0
            term = 0
            # Rejection dates in 2024 and 2025
            appr_date = rand_date(datetime(2024,1,1), datetime(2025,12,31))
        else:
            loan_amt = round(rng.uniform(1000, 300000), 2)
            interest = round(rng.uniform(1.0, 12.0), 2)
            term = pick([12,24,36,48,60,120])
            # Approved/Closed can be broader
            appr_date = rand_date(datetime(2015,1,1), datetime(2025,12,31))
        loans.append({
            "Loan ID": NEXT_LOAN_ID,
            "Loan Amount": loan_amt,
            "Loan Type": loan_type,
            "Interest Rate": interest,
            "Loan Term": term,
            "Approval/Rejection Date": appr_date,
            "Loan Status": status,
        })
        NEXT_LOAN_ID += 1
    return loans


def gen_transactions(cust_id: int, accounts: List[Dict[str, Any]], cards: List[Dict[str, Any]], loans: List[Dict[str, Any]], profile_cfg: Optional[Dict[str, Any]] = None, cust_branch_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Generate up to MAX_TXNS_PER_CUST transactions only if accounts exist; may tie to a card/loan."""
    global NEXT_TXN_ID
    # Poisson-like distribution
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    mean = max(0, int(profile_cfg.get("txns_mean", 8)))
    # If no accounts, do not generate transactions
    if not accounts:
        n = 0
    else:
        # Between 25 and 100 per requirement
        n = rng.randint(MIN_TXNS_PER_CUST, MAX_TXNS_PER_CUST)
    txns = []
    for _ in range(n):
        if accounts:
            acc = pick(accounts)
        else:
            acc = None
        ttype = pick(["Deposit","Withdrawal","Payment","Transfer"])
        amt = round(rng.uniform(10, 5000), 2)
        after_bal = None
        if acc is not None:
            delta = amt if ttype in ("Deposit",) else -amt if ttype in ("Withdrawal","Payment") else rng.uniform(-amt, amt)
            after_bal = round(acc["Account Balance"] + delta, 2)
        # Use the customer's assigned branch for transactions (not random)
        branch_id = int(cust_branch_id or 0)
        # Transaction dates in 2024 and 2025
        tdate = rand_date(datetime(2024,1,1), datetime(2025,12,31))

        # Optionally tie to a card or loan for some transactions
        use_card = cards and (ttype in ("Payment","Transfer")) and rng.random() < 0.35
        use_loan = loans and (ttype in ("Payment","Transfer")) and not use_card and rng.random() < 0.25
        card = pick(cards) if use_card else None
        loan = pick(loans) if use_loan else None

        txns.append({
            "TransactionID": NEXT_TXN_ID,
            "Transaction Date": tdate,
            "Transaction Type": ttype,
            "Transaction Amount": amt,
            "Account Balance After Transaction": after_bal if after_bal is not None else 0.0,
            "Branch ID": branch_id,
            "AccountID": acc["AccountID"] if acc else 0,
            "Card": card,
            "Loan": loan
        })
        NEXT_TXN_ID += 1
    return txns


def to_flat_rows(cust: Dict[str, Any], accounts, cards, loans, txns, feedback, profile_cfg: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
    """Flatten entities into ORIGINAL_COLS + extras with RowType and per-row sanitization."""
    rows: List[Dict[str, Any]] = []

    # metadata
    has_cards = 1 if len(cards) > 0 else 0
    has_loans = 1 if len(loans) > 0 else 0
    has_multi_accounts = 1 if len(accounts) > 1 else 0

    # helpers to sanitize fields by entity
    def clear_card_fields(r: Dict[str, Any]):
        r["CardID"] = 0
        r["Card Type"] = ""
        r["Credit Limit"] = 0
        r["Credit Card Balance"] = 0
        r["Minimum Payment Due"] = 0
        r["Payment Due Date"] = ""
        r["Last Credit Card Payment Date"] = ""

    def clear_loan_fields(r: Dict[str, Any]):
        r["Loan ID"] = 0
        r["Loan Amount"] = 0
        r["Loan Type"] = ""
        r["Interest Rate"] = 0
        r["Loan Term"] = 0
        r["Approval/Rejection Date"] = ""
        r["Loan Status"] = ""

    # derive customer-level enrichment
    total_balance = sum(a["Account Balance"] for a in accounts) if accounts else 0.0
    if profile_cfg is None:
        profile_cfg = get_profile_cfg("balanced")
    cs_lo, cs_hi = profile_cfg.get("credit_score_range", (580,780))
    inc_lo, inc_hi = profile_cfg.get("income_range", (30000,120000))
    credit_score = rng.randint(cs_lo, cs_hi)
    income = rng.randint(inc_lo, inc_hi)
    if credit_score < 580:
        cust_segment = "High Risk"
    elif income > 100000 and total_balance > 50000:
        cust_segment = "High Value"
    elif income < 40000:
        cust_segment = "Budget"
    else:
        cust_segment = pick(["At Risk","Digital Enthusiast","Stable"]) 
    ch_lo, ch_hi = profile_cfg.get("churn_range", (0.05,0.6))
    dig_lo, dig_hi = profile_cfg.get("digital_range", (20,85))
    churn_prob = round(rng.uniform(ch_lo, ch_hi), 2)
    digital_score = rng.randint(dig_lo, dig_hi)

    # Compute customer-level anomaly (business outliers; not data errors)
    util_avg = 0.0
    if cards:
        tot_lim = sum(c.get("Credit Limit", 0) for c in cards)
        tot_bal = sum(c.get("Credit Card Balance", 0) for c in cards)
        util_avg = (tot_bal / tot_lim) if tot_lim > 0 else 0.0

    # Thresholds relative to profile ranges to avoid being too strict for some profiles
    churn_thr = max(ch_hi - 0.05, ch_lo + 0.8 * (ch_hi - ch_lo))  # top ~20% of churn range
    digital_thr = max(dig_hi - 5, int(dig_lo + 0.85 * (dig_hi - dig_lo)))  # top tail of digital range
    util_thr = 0.50
    txn_thr = max(95, int(0.95 * MAX_TXNS_PER_CUST))  # default 95 when MAX=100
    income_low = inc_lo + 2000
    balance_high = 80000

    customer_anomaly = 0
    if (churn_prob >= churn_thr and digital_score >= digital_thr):
        customer_anomaly = 1
    elif util_avg >= util_thr:
        customer_anomaly = 1
    elif len(txns) >= txn_thr:
        customer_anomaly = 1
    elif income <= income_low and total_balance >= balance_high:
        customer_anomaly = 1

    # Helper to build base row with customer + defaults
    def base() -> Dict[str, Any]:
        """Initialize a row with customer and feedback values, zeros elsewhere."""
        row = zero_row()
        # fill customer
        for k, v in cust.items():
            row[k] = v
        # feedback per customer
        row["Feedback ID"] = feedback["Feedback ID"]
        row["Feedback Date"] = feedback["Feedback Date"]
        row["Feedback Type"] = feedback["Feedback Type"]
        row["Resolution Status"] = feedback["Resolution Status"]
        row["Resolution Date"] = feedback["Resolution Date"]
        row["Rewards Points"] = feedback["Rewards Points"]
        # feedback text (in extra columns)
        row["FeedbackText"] = feedback.get("FeedbackText", "")
        # branch info
        row["Branch ID"] = cust.get("Branch ID", 0)
        row["Branch Name"] = cust.get("Branch Name", "")
        return row

    # Account rows
    for i, acc in enumerate(accounts, start=1):
        r = base()
        r["RowType"] = "Account"
        r["EntitySequence"] = i
        r["AccountID"] = acc["AccountID"]
        r["Account Type"] = acc["Account Type"]
        r["Account Balance"] = acc["Account Balance"]
        r["Date Of Account Opening"] = acc["Date Of Account Opening"]
        r["EventTimestamp"] = rand_date(datetime(2022,1,1), datetime(2024,12,31))
        # clear unrelated entity fields
        clear_card_fields(r)
        clear_loan_fields(r)
        rows.append(r)

    # Card rows
    for i, card in enumerate(cards, start=1):
        r = base()
        r["RowType"] = "Card"
        r["EntitySequence"] = i
        r["CardID"] = card["CardID"]
        r["Card Type"] = card["Card Type"]
        r["Credit Limit"] = card["Credit Limit"]
        r["Credit Card Balance"] = card["Credit Card Balance"]
        r["Minimum Payment Due"] = card["Minimum Payment Due"]
        r["Payment Due Date"] = card["Payment Due Date"]
        r["Last Credit Card Payment Date"] = card["Last Credit Card Payment Date"]
        r["EventTimestamp"] = rand_date(datetime(2022,1,1), datetime(2024,12,31))
        # clear unrelated entity fields
        clear_loan_fields(r)
        rows.append(r)

    # Loan rows
    for i, loan in enumerate(loans, start=1):
        r = base()
        r["RowType"] = "Loan"
        r["EntitySequence"] = i
        r["Loan ID"] = loan["Loan ID"]
        r["Loan Amount"] = loan["Loan Amount"]
        r["Loan Type"] = loan["Loan Type"]
        r["Interest Rate"] = loan["Interest Rate"]
        r["Loan Term"] = loan["Loan Term"]
        r["Approval/Rejection Date"] = loan["Approval/Rejection Date"]
        r["Loan Status"] = loan["Loan Status"]
        r["EventTimestamp"] = rand_date(datetime(2015,1,1), datetime(2024,12,31))
        # clear unrelated entity fields
        clear_card_fields(r)
        rows.append(r)

    # Transaction rows
    for i, t in enumerate(txns, start=1):
        r = base()
        r["RowType"] = "Transaction"
        r["EntitySequence"] = i
        r["TransactionID"] = t["TransactionID"]
        r["Transaction Date"] = t["Transaction Date"]
        r["Transaction Type"] = t["Transaction Type"]
        r["Transaction Amount"] = t["Transaction Amount"]
        r["Account Balance After Transaction"] = t["Account Balance After Transaction"]
        r["AccountID"] = t["AccountID"]
        # carry account info if known
        if t["AccountID"]:
            r["Account Type"] = next((a["Account Type"] for a in accounts if a["AccountID"]==t["AccountID"]), "")
            r["Date Of Account Opening"] = next((a["Date Of Account Opening"] for a in accounts if a["AccountID"]==t["AccountID"]), "")
        # card/loan tie-ins
        if t["Card"]:
            c = t["Card"]
            r["CardID"] = c["CardID"]
            r["Card Type"] = c["Card Type"]
            r["Credit Limit"] = c["Credit Limit"]
            r["Credit Card Balance"] = c["Credit Card Balance"]
            r["Minimum Payment Due"] = c["Minimum Payment Due"]
            r["Payment Due Date"] = c["Payment Due Date"]
            r["Last Credit Card Payment Date"] = c["Last Credit Card Payment Date"]
        else:
            clear_card_fields(r)
        if t["Loan"]:
            l = t["Loan"]
            r["Loan ID"] = l["Loan ID"]
            r["Loan Amount"] = l["Loan Amount"]
            r["Loan Type"] = l["Loan Type"]
            r["Interest Rate"] = l["Interest Rate"]
            r["Loan Term"] = l["Loan Term"]
            r["Approval/Rejection Date"] = l["Approval/Rejection Date"]
            r["Loan Status"] = l["Loan Status"]
        else:
            clear_loan_fields(r)
        r["EventTimestamp"] = t["Transaction Date"]
        rows.append(r)

    # Snapshot row if customer had no entities
    if not rows:
        r = base()
        r["RowType"] = "Snapshot"
        r["EntitySequence"] = 1
        r["EventTimestamp"] = rand_date(datetime(2022,1,1), datetime(2024,12,31))
        rows.append(r)

    # pre-compute latest transaction date
    latest_txn_date_str = ""
    if txns:
        try:
            latest = max(datetime.strptime(t["Transaction Date"], DATE_FMT) for t in txns)
            latest_txn_date_str = latest.strftime(DATE_FMT)
        except Exception:
            latest_txn_date_str = ""

    # annotate counts and enrichment on each row
    for r in rows:
        r["CustomerHasCards"] = has_cards
        r["CustomerHasLoans"] = has_loans
        r["CustomerHasMultipleAccounts"] = has_multi_accounts
        r["CustomerCardCount"] = len(cards)
        r["CustomerLoanCount"] = len(loans)
        r["CustomerAccountCount"] = len(accounts)
        r["CustomerTxnCount"] = len(txns)
        # enrichment columns
        r["ChurnLikelihood"] = churn_prob
        r["CustomerSegment"] = cust_segment
        r["DigitalEngagementScore"] = digital_score
        # Last Transaction Date for convenience
        if latest_txn_date_str:
            r["Last Transaction Date"] = latest_txn_date_str
    # Set anomaly per row from customer-level computation
    r["Anomaly"] = customer_anomaly
    return rows


def main(num_customers: int = NUM_CUSTOMERS, region: str = "all", profile: str = "balanced", progress_every: int = 100):
    """Driver: generates flat and star-schema CSVs for the requested number of customers.

    region: 'all' | 'east' | 'west'
    """
    global NEXT_FB_ID, NEXT_ACCOUNT_ID
    out_rows: List[Dict[str, Any]] = []
    # star-schema collections
    customers_norm: List[Dict[str, Any]] = []
    accounts_norm: List[Dict[str, Any]] = []
    cards_norm: List[Dict[str, Any]] = []
    loans_norm: List[Dict[str, Any]] = []
    txns_norm: List[Dict[str, Any]] = []
    feedback_norm: List[Dict[str, Any]] = []

    profile_cfg = get_profile_cfg(profile)

    print(f"Starting generation for {num_customers} customers (profile={profile}, region={region})...")
    for cust_id in range(1, num_customers + 1):
        cust = make_customer(cust_id, region=region, profile_cfg=profile_cfg)
        accounts = gen_accounts(cust_id, profile_cfg=profile_cfg)
        cards = gen_cards(cust_id, profile_cfg=profile_cfg)
        loans = gen_loans(cust_id, profile_cfg=profile_cfg, branch_city=cust["City"])

        # Enforce: any customer with a loan or a credit card must have a checking (Current) account
        if (cards or loans) and not any(a["Account Type"] == "Current" for a in accounts):
            accounts.append({
                "AccountID": NEXT_ACCOUNT_ID,
                "Account Type": "Current",
                "Account Balance": round(rng.uniform(100, 150000), 2),
                "Date Of Account Opening": rand_date(datetime(2010,1,1), datetime(2025,12,31))
            })
            NEXT_ACCOUNT_ID += 1

        txns = gen_transactions(cust_id, accounts, cards, loans, profile_cfg=profile_cfg, cust_branch_id=cust["Branch ID"])

        # Only cardholders have rewards
        feedback = make_feedback(has_card=bool(cards))
        feedback["Feedback ID"] = NEXT_FB_ID
        NEXT_FB_ID += 1

        flat = to_flat_rows(cust, accounts, cards, loans, txns, feedback, profile_cfg=profile_cfg)
        out_rows.extend(flat)
        # lightweight progress
        if progress_every and (cust_id % progress_every == 0 or cust_id == num_customers):
            print(f"  - Generated customers: {cust_id}/{num_customers}")
            sys.stdout.flush()

        # Customers
        customers_norm.append({
            "Customer ID": cust["Customer ID"],
            "First Name": cust["First Name"],
            "Last Name": cust["Last Name"],
            "Age": cust["Age"],
            "Gender": cust["Gender"],
            "Address": cust["Address"],
            "City": cust["City"],
            "State": cust.get("State", ""),
            "Zip Code": cust.get("Zip Code", ""),
            "Country": cust.get("Country", "United States"),
            "Contact Number": cust["Contact Number"],
            "Email": cust["Email"],
            # Use computed anomaly from flattened rows
            "Anomaly": flat[0].get("Anomaly", 0),
            "Branch ID": cust.get("Branch ID", 0),
            "Branch Name": cust.get("Branch Name", ""),
            "CustomerSegment": flat[0].get("CustomerSegment", ""),
            "ChurnLikelihood": flat[0].get("ChurnLikelihood", 0),
            "DigitalEngagementScore": flat[0].get("DigitalEngagementScore", 0),
            "Rewards Points": feedback.get("Rewards Points", 0),
        })

        # Accounts
        for acc in accounts:
            accounts_norm.append({
                "AccountID": acc["AccountID"],
                "Customer ID": cust["Customer ID"],
                "Account Type": acc["Account Type"],
                "Date Of Account Opening": acc["Date Of Account Opening"],
                "Account Balance": acc["Account Balance"],
            })

        # Cards
        for card in cards:
            cards_norm.append({
                "CardID": card["CardID"],
                "Customer ID": cust["Customer ID"],
                "Card Type": card["Card Type"],
                "Credit Limit": card["Credit Limit"],
                "Credit Card Balance": card["Credit Card Balance"],
                "Minimum Payment Due": card["Minimum Payment Due"],
                "Payment Due Date": card["Payment Due Date"],
                "Last Credit Card Payment Date": card["Last Credit Card Payment Date"],
            })

        # Loans
        for loan in loans:
            loans_norm.append({
                "Loan ID": loan["Loan ID"],
                "Customer ID": cust["Customer ID"],
                "Loan Amount": loan["Loan Amount"],
                "Loan Type": loan["Loan Type"],
                "Interest Rate": loan["Interest Rate"],
                "Loan Term": loan["Loan Term"],
                "Approval/Rejection Date": loan["Approval/Rejection Date"],
                "Loan Status": loan["Loan Status"],
            })

        # Transactions
        for t in txns:
            txns_norm.append({
                "TransactionID": t["TransactionID"],
                "Customer ID": cust["Customer ID"],
                "AccountID": t.get("AccountID", 0),
                "Transaction Date": t["Transaction Date"],
                "Transaction Type": t["Transaction Type"],
                "Transaction Amount": t["Transaction Amount"],
                "Account Balance After Transaction": t["Account Balance After Transaction"],
                "Branch ID": t["Branch ID"],
                "CardID": (t["Card"]["CardID"] if t.get("Card") else 0),
                "Loan ID": (t["Loan"]["Loan ID"] if t.get("Loan") else 0),
            })

        # Feedback (one per customer)
        feedback_norm.append({
            "Feedback ID": feedback["Feedback ID"],
            "Customer ID": cust["Customer ID"],
            "Feedback Date": feedback["Feedback Date"],
            "Feedback Type": feedback["Feedback Type"],
            "Resolution Status": feedback["Resolution Status"],
            "Resolution Date": feedback["Resolution Date"],
            "Rewards Points": feedback["Rewards Points"],
            "FeedbackText": feedback.get("FeedbackText", ""),
    })

    # Build DataFrame with all columns in order
    df = pd.DataFrame(out_rows, columns=ALL_COLS)

    # Derive anomaly per customer using distribution-aware thresholds
    try:
        # Series from flat df
        churn_s = df.groupby("Customer ID")["ChurnLikelihood"].max()
        digital_s = df.groupby("Customer ID")["DigitalEngagementScore"].max()
        # Transaction count per customer
        txn_counts_s = df.loc[df["RowType"] == "Transaction"].groupby("Customer ID").size()
        # Utilization from cards
        if cards_norm:
            cards_df_tmp = pd.DataFrame(cards_norm)
            util_s = (cards_df_tmp.groupby("Customer ID")["Credit Card Balance"].sum() /
                      cards_df_tmp.groupby("Customer ID")["Credit Limit"].sum()).fillna(0)
        else:
            util_s = pd.Series(dtype=float)
        # Total balances from accounts
        if accounts_norm:
            accounts_df_tmp = pd.DataFrame(accounts_norm)
            balance_s = accounts_df_tmp.groupby("Customer ID")["Account Balance"].sum()
        else:
            balance_s = pd.Series(dtype=float)

        # Quantile thresholds (fallback to sensible constants when insufficient data)
        def q_or(series, q, default):
            return float(series.quantile(q)) if len(series) > 0 else default

        churn_thr_q = q_or(churn_s, 0.80, 0.75)
        digital_thr_q = q_or(digital_s, 0.80, 75)
        util_thr_q = max(q_or(util_s, 0.85, 0.50), 0.48)
        txn_thr_q = max(int(q_or(txn_counts_s, 0.85, 90)), 90)
        balance_thr_q = q_or(balance_s, 0.90, 80000)

        # Build anomaly map
        all_ids = set(churn_s.index) | set(digital_s.index) | set(txn_counts_s.index) | set(util_s.index) | set(balance_s.index)
        anomaly_map = {}
        for cid in all_ids:
            churn_v = churn_s.get(cid, 0)
            dig_v = digital_s.get(cid, 0)
            util_v = util_s.get(cid, 0)
            txn_v = int(txn_counts_s.get(cid, 0))
            bal_v = balance_s.get(cid, 0)
            flag = 0
            if churn_v >= churn_thr_q and dig_v >= digital_thr_q:
                flag = 1
            elif util_v >= util_thr_q:
                flag = 1
            elif txn_v >= txn_thr_q:
                flag = 1
            elif bal_v >= balance_thr_q and util_v >= 0.45:
                flag = 1
            anomaly_map[cid] = flag

        if anomaly_map:
            df["Anomaly"] = df["Customer ID"].map(anomaly_map).fillna(0).astype(int)
    except Exception as _e:
        # If anything goes wrong, keep existing values
        pass

    # Ensure numeric columns are proper dtypes (Power BI-friendly)
    numeric_cols = [
        "Customer ID","Age","Account Balance","TransactionID","Transaction Amount",
        "Account Balance After Transaction","Branch ID","Loan ID","Loan Amount","Interest Rate",
        "Loan Term","CardID","Credit Limit","Credit Card Balance","Minimum Payment Due",
    "Rewards Points","Anomaly","EntitySequence","AccountID",
        "CustomerHasCards","CustomerHasLoans","CustomerHasMultipleAccounts",
    "CustomerCardCount","CustomerLoanCount","CustomerAccountCount","CustomerTxnCount",
    "DigitalEngagementScore","ChurnLikelihood"
    ]
    for c in numeric_cols:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0).astype(float if c in ["Account Balance","Transaction Amount","Account Balance After Transaction","Loan Amount","Interest Rate","Credit Limit","Credit Card Balance","Minimum Payment Due"] else int)

    # Output (flat file goes to root/output)
    out_dir = os.path.join(_ROOT, "output")
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, "Project1-Comprehensive_Banking_Database-new.csv")
    df.to_csv(out_path, index=False)
    print(f"Wrote {len(df):,} rows to {out_path}")

    # Write star-schema exports to root/star_schema
    out_dir = os.path.join(_ROOT, "star_schema")
    os.makedirs(out_dir, exist_ok=True)

    customers_df = pd.DataFrame(customers_norm, columns=[
        "Customer ID","First Name","Last Name","Age","Gender","Address","City","State","Zip Code","Country",
        "Contact Number","Email","Anomaly","Branch ID","Branch Name","CustomerSegment","ChurnLikelihood","DigitalEngagementScore","Rewards Points"
    ])
    # Overwrite Anomaly from the computed map if available
    try:
        if 'anomaly_map' in locals() and anomaly_map:
            customers_df['Anomaly'] = customers_df['Customer ID'].map(anomaly_map).fillna(0).astype(int)
    except Exception:
        pass
    customers_df.to_csv(os.path.join(out_dir, "Customers.csv"), index=False)

    pd.DataFrame(accounts_norm, columns=[
        "AccountID","Customer ID","Account Type","Date Of Account Opening","Account Balance"
    ]).to_csv(os.path.join(out_dir, "Accounts.csv"), index=False)

    pd.DataFrame(cards_norm, columns=[
        "CardID","Customer ID","Card Type","Credit Limit","Credit Card Balance","Minimum Payment Due","Payment Due Date","Last Credit Card Payment Date"
    ]).to_csv(os.path.join(out_dir, "Cards.csv"), index=False)

    pd.DataFrame(loans_norm, columns=[
        "Loan ID","Customer ID","Loan Amount","Loan Type","Interest Rate","Loan Term","Approval/Rejection Date","Loan Status"
    ]).to_csv(os.path.join(out_dir, "Loans.csv"), index=False)

    pd.DataFrame(txns_norm, columns=[
        "TransactionID","Customer ID","AccountID","Transaction Date","Transaction Type","Transaction Amount","Account Balance After Transaction","Branch ID","CardID","Loan ID"
    ]).to_csv(os.path.join(out_dir, "Transactions.csv"), index=False)

    pd.DataFrame(feedback_norm, columns=[
        "Feedback ID","Customer ID","Feedback Date","Feedback Type","Resolution Status","Resolution Date","Rewards Points","FeedbackText"
    ]).to_csv(os.path.join(out_dir, "Feedback.csv"), index=False)

    # Branches star table
    branches_df = pd.DataFrame([{
        "Branch ID": b["id"],
        "Branch Name": b["name"],
        "City": b["city"],
        "State": b["state"],
        "Weight": b.get("weight", 0.0),
    } for b in BRANCHES], columns=["Branch ID","Branch Name","City","State","Weight"]) 
    branches_df.to_csv(os.path.join(out_dir, "Branches.csv"), index=False)

    # Branch load report (customers/accounts/cards/loans/txns per branch)
    # Build maps from Customers table
    cust_df = pd.DataFrame(customers_norm)
    if not cust_df.empty:
        bmap = cust_df[["Customer ID","Branch ID","Branch Name","City","State"]]
        # counts per customer
        def count_by_branch(items: List[Dict[str, Any]], key: str) -> pd.Series:
            if not items:
                return pd.Series(dtype=int)
            df = pd.DataFrame(items)
            grp = df.groupby("Customer ID").size()
            merged = bmap.merge(grp.rename(key), left_on="Customer ID", right_index=True, how="left").fillna(0)
            return merged.groupby(["Branch ID","Branch Name","City","State"])[key].sum()

        cust_counts = bmap.groupby(["Branch ID","Branch Name","City","State"]).size().rename("Customers")
        acc_counts = count_by_branch(accounts_norm, "Accounts") if accounts_norm else pd.Series(dtype=int)
        card_counts = count_by_branch(cards_norm, "Cards") if cards_norm else pd.Series(dtype=int)
        loan_counts = count_by_branch(loans_norm, "Loans") if loans_norm else pd.Series(dtype=int)
        txn_counts = count_by_branch(txns_norm, "Transactions") if txns_norm else pd.Series(dtype=int)

        # combine
        rep = pd.DataFrame(cust_counts).reset_index()
        for s, name in [(acc_counts, "Accounts"),(card_counts, "Cards"),(loan_counts, "Loans"),(txn_counts, "Transactions")]:
            if isinstance(s, pd.Series) and not s.empty:
                rep = rep.merge(s.reset_index(), on=["Branch ID","Branch Name","City","State"], how="left")
        for col in ["Accounts","Cards","Loans","Transactions"]:
            if col in rep.columns:
                rep[col] = rep[col].fillna(0).astype(int)
            else:
                rep[col] = 0
        total_cust = rep["Customers"].sum()
        rep["Customer Share %"] = (rep["Customers"] / total_cust * 100.0).round(2)
        # write report
        os.makedirs(os.path.join(_ROOT, "output"), exist_ok=True)
        rep.sort_values(["Customers"], ascending=False).to_csv(os.path.join(_ROOT, "output", "Branch_Load_Report.csv"), index=False)

    print(f"Wrote star schema tables to {out_dir}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Generate synthetic banking dataset")
    parser.add_argument("--customers", type=int, default=NUM_CUSTOMERS, help="Number of customers to generate")
    parser.add_argument("--region", choices=["all","east","west"], default="all", help="Geographic region for US states")
    parser.add_argument("--profile", choices=["balanced","high_value","budget","at_risk","digital_enthusiast"], default="balanced", help="Customer profile preset")
    parser.add_argument("--progress", type=int, default=100, help="Print progress every N customers (0 to disable)")
    args = parser.parse_args()
    target_customers = max(1, int(args.customers))
    main(target_customers, region=args.region, profile=args.profile, progress_every=max(0, int(args.progress)))
