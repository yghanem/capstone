import os
import csv
from collections import Counter

BASE = os.path.dirname(__file__)
files = {
    'Flat': os.path.join(BASE, 'Project1-Comprehensive_Banking_Database-new.csv'),
    'Customers': os.path.join(BASE, 'star_schema', 'Customers.csv'),
    'Accounts': os.path.join(BASE, 'star_schema', 'Accounts.csv'),
    'Cards': os.path.join(BASE, 'star_schema', 'Cards.csv'),
    'Loans': os.path.join(BASE, 'star_schema', 'Loans.csv'),
    'Transactions': os.path.join(BASE, 'star_schema', 'Transactions.csv'),
    'Feedback': os.path.join(BASE, 'star_schema', 'Feedback.csv'),
}

def norm(name: str) -> str:
    # normalize: strip, lower, collapse internal whitespace
    return " ".join(name.strip().lower().split())

for name, path in files.items():
    try:
        with open(path, 'r', newline='', encoding='utf-8') as f:
            reader = csv.reader(f)
            header = next(reader)
    except Exception as e:
        print(f"{name}: ERROR reading {path}: {e}")
        continue

    total = len(header)
    counts = Counter(header)
    dup_exact = {k: v for k, v in counts.items() if v > 1}

    norm_counts = Counter(norm(h) for h in header)
    dup_norm = {k: v for k, v in norm_counts.items() if v > 1}

    print(f"{name}: {total} columns")
    if dup_exact:
        print("  Duplicates (exact):")
        for k, v in dup_exact.items():
            print(f"    - {k}: {v}")
    if dup_norm and not dup_exact:
        print("  Duplicates (normalized case/space):")
        for k, v in dup_norm.items():
            print(f"    - {k}: {v}")
    if not dup_exact and not dup_norm:
        print("  No duplicates detected.")
