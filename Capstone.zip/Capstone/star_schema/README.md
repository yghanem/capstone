# Star schema guide

This folder contains normalized CSVs for modeling in Power BI. Use these as dimensions/facts and build relationships as outlined below.

## Tables and keys

- Customers (dimension)
  - PK: Customer ID
  - Columns: First/Last Name, Age, Gender, Address, City, State, Zip Code (text), Country, Contact Number, Email, Anomaly, CustomerSegment, ChurnLikelihood, DigitalEngagementScore
- Accounts (dimension)
  - PK: AccountID
  - FK: Customer ID → Customers[Customer ID]
  - Columns: Account Type, Date Of Account Opening, Account Balance
- Cards (dimension)
  - PK: CardID
  - FK: Customer ID → Customers[Customer ID]
  - Columns: Card Type, Credit Limit, Credit Card Balance, Minimum Payment Due, Payment Due Date, Last Credit Card Payment Date
- Loans (dimension)
  - PK: Loan ID
  - FK: Customer ID → Customers[Customer ID]
  - Columns: Loan Amount, Loan Type, Interest Rate, Loan Term, Approval/Rejection Date, Loan Status
- Feedback (fact-less/degenerate dim)
  - PK: Feedback ID
  - FK: Customer ID → Customers[Customer ID]
  - Columns: Feedback Date, Feedback Type, Resolution Status, Resolution Date, Rewards Points, FeedbackText
- Transactions (fact)
  - PK: TransactionID
  - FKs:
    - AccountID → Accounts[AccountID] (recommended active)
    - CardID → Cards[CardID] (sparse; recommended inactive)
    - Loan ID → Loans[Loan ID] (sparse; recommended inactive)
    - Customer ID → Customers[Customer ID] (optional; recommended inactive to avoid ambiguity)
  - Columns: Transaction Date, Transaction Type, Transaction Amount, Account Balance After Transaction, Branch ID

## Recommended relationships (Power BI)

Create single-direction relationships from dimensions to facts.

Active

- Customers[Customer ID] 1 → \* Accounts[Customer ID]
- Customers[Customer ID] 1 → \* Cards[Customer ID]
- Customers[Customer ID] 1 → \* Loans[Customer ID]
- Customers[Customer ID] 1 → \* Feedback[Customer ID]
- Accounts[AccountID] 1 → \* Transactions[AccountID]

Inactive (create but set to inactive; enable in measures via USERELATIONSHIP)

- Cards[CardID] 1 → \* Transactions[CardID]
- Loans[Loan ID] 1 → \* Transactions[Loan ID]
- (Optional) Customers[Customer ID] 1 → \* Transactions[Customer ID]

Reasoning: Keeping Accounts→Transactions as the only active path to Transactions avoids ambiguity from parallel paths (Customers→Transactions and Customers→Accounts→Transactions). Use USERELATIONSHIP when you need to analyze Transactions by Card or Loan.

## Data types (suggested)

- IDs: Whole number (Customer ID, AccountID, CardID, Loan ID, TransactionID, Feedback ID)
- Monetary amounts: Fixed decimal number with 2 decimals (Account Balance, Transaction Amount, Account Balance After Transaction, Credit Limit, Credit Card Balance, Minimum Payment Due, Loan Amount)
- Rates/Percentages: Decimal number (Interest Rate), Decimal number 0–1 (ChurnLikelihood)
- Counts/Terms: Whole number (Loan Term, Rewards Points, Anomaly)
- Dates: Date (mm/dd/yyyy)
- Codes/Text: Text (Account Type, Card Type, Loan Type, City, State, Zip Code, Country, Email, Feedback/Resolution fields, CustomerSegment)
- Zip Code: Text (kept as 5-digit string)

## Date table (recommended)

Create a dedicated Date dimension and relate it as needed:

- Date → Transactions[Transaction Date] (active)
- Optionally create inactive relationships to: Accounts[Date Of Account Opening], Loans[Approval/Rejection Date], Cards[Payment Due Date], Cards[Last Credit Card Payment Date], Feedback[Feedback Date], Feedback[Resolution Date]. Activate with USERELATIONSHIP in measures.

## Starter measures (optional)

- Total Transactions = SUM(Transactions[Transaction Amount])
- Average Balance = AVERAGE(Accounts[Account Balance])
- Customers Count = DISTINCTCOUNT(Customers[Customer ID])
- Active Cards Txn = CALCULATE(SUM(Transactions[Transaction Amount]), USERELATIONSHIP(Cards[CardID], Transactions[CardID]))
- Loan-related Txn = CALCULATE(SUM(Transactions[Transaction Amount]), USERELATIONSHIP(Loans[Loan ID], Transactions[Loan ID]))

## Import order

1. Customers
2. Accounts, Cards, Loans, Feedback
3. Transactions

Then create relationships as above. If Power BI warns about ambiguous paths, set the Customer→Transactions relationship to inactive or remove it entirely.
